def select_even_nums(arr)
    arr.select(&:even?)
end

def reject_puppies(dog)
    dog.reject {|pup| pup["age"] <= 2}
end

def count_positive_subarrays(arr)
    arr.count { |ele| ele.sum > 0}
end

def aba_translate(word)
    word.gsub(/(?<vowel>[aeiou])/,'\k<vowel>b\k<vowel>')
end

def aba_array(arr)
    arr.map {|word| aba_translate(word)}
end