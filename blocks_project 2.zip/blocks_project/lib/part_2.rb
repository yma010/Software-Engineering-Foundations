def all_words_capitalized?(array)
    array.all? { |word| word.capitalize == word }
end

def no_valid_url?(urls)
    endings = ['.com', '.net', '.io', '.org']
    
    urls.none? do |url|
        endings.any? { |ending| url.end_with?(ending)}
    end
end

def any_passing_students?(students)
    students.any? do |student|
       avg = student[:grades].sum / student[:grades].length.to_f
       return true if avg >= 75
    end
    false
end

