def my_reject(arr, &prc)
    rejected = []
    arr.each do |ele|
        if prc.call(ele) == false
            rejected << ele
        end
    end
    rejected
end

def my_one?(arr, &prc)
    count = 0

    arr.each do |ele|
        if prc.call(ele) == true
            count +=1
        end
    end
    if count === 1
        return true
    else
        false
    end
end

def hash_select(hash, &prc)
    selected = Hash.new {}

    hash.each do |k , v|
        if prc.call(k , v) == true
            selected[k] = v
        end
    end
    selected
end

def xor_select(arr, prcA, prcB)
    new_arr = []
    arr.each do |ele|
        if ((prcA.call(ele) == true) && (prcB.call(ele) == false)) || ((prcA.call(ele) == false) && (prcB.call(ele) == true))
            new_arr << ele
        end
    end
    new_arr
end

def proc_count(num, arr)
    count = 0

    arr.each do |prc|
        if prc.call(num) == true
            count +=1
        end
    end
    count
end
