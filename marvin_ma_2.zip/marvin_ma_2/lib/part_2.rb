require "byebug"
def proper_factors(num)
    n = 1
    factors = []
    while n < num
        if num%n == 0 && num > n 
            factors << n
        end
        n +=1
    end
    factors
end

def aliquot_sum(num)
    return proper_factors(num).sum
end

def perfect_number?(num)
    if num == aliquot_sum(num)
        return true
    end
    false
end

def ideal_numbers(n)
    ideal = []
    count = 6
    while ideal.length < n
        #byebug
        if perfect_number?(count) == true
            ideal << aliquot_sum(count)
        end
        count +=1
    end
    ideal
end
