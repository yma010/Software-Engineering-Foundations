require_relative "Board"

class Game

    def initialize 
    end
    

    
end