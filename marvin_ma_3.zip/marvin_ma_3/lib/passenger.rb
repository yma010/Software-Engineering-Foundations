class Passenger
    attr_reader :name

    def initialize(name)
        @name = name
        @flight_numbers = []
    end

    def has_flight?(flightNumber) #Checks if flight number is valid. Upcase to check for invalid lower chars
        return true if @flight_numbers.any?(flightNumber.upcase)
        false
    end

    def add_flight(flightNumber) #Shovels flight number in. Upcase in case of bad user input
        @flight_numbers << flightNumber.upcase if !has_flight?(flightNumber)
    end

end