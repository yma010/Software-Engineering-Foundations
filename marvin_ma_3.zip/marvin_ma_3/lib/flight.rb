class Flight
    attr_reader :passengers
    def initialize(flight_number, capacity)
        @flight_number = flight_number
        @capacity = capacity
        @passengers = []
    end

    def full? #Checks if passenger array size is the same as capacity size
        return true if @passengers.length == @capacity
        false
    end

    def board_passenger(passenger) #If full? returns false and has_flight? returns true shovel passenger into the array
        @passengers << passenger if !full? && passenger.has_flight?(@flight_number)
    end

    def list_passengers #Iterates through the passenger array. Calls .name and maps it to an array
        @passengers.map {|passenger| passenger.name}
    end
    
    def [] (index)
        @passengers[index]
    end

    def << passenger
        board_passenger(passenger)
    end
end