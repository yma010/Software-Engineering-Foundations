def element_count(arr)
    element = Hash.new{0}

    arr.each do |count|
        element[count] +=1
    end
    return element
end

def char_replace!(str, hash)
    str.each_char.with_index do |val, i|
        if hash.has_key?(val)
            str[i] = hash[val]
        end
    end
    return str
end

def product_inject(arr)
    arr.inject { |acc, el| acc * el}
end
