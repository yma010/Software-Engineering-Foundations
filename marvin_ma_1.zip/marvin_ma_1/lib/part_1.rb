def is_prime?(num)
    if num < 2
        return false
    end
    (2...num).each do |factor|
        if num % factor == 0
            return false
        end
    end
  return true
end

def nth_prime(n)
    if n == 1
        return 2
    end
    i = 1
    num = 3
    while (i <= n)
        if is_prime?(num)
            i +=1
            if i == n
                return num
            end
        end
        num +=2
    end
end

def prime_range(min, max)
    prime = []
    (min..max).each do |num|
        if is_prime?(num) == true
            prime << num
        end
    end
    return prime
end
