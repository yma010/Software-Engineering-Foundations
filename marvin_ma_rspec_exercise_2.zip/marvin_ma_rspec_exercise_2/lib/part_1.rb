def partition(arr, arg)
    smallList = []
    bigList = []

    arr.each do |ele|
        if ele >= arg
            bigList << ele
        else
            smallList << ele
        end
    end
    return [smallList, bigList]
end

def merge(hash1, hash2)
    new_hash = {}
    hash1.each { |k,v| new_hash[k] = v}
    hash2.each { |k,v| new_hash[k] = v}
    return new_hash
end

def censor(message, curse)
    words = message.split(" ")
    censored_words = words.map do |word|
        if curse.include?(word.downcase)
            censoring(word)
        else
            word
        end
    end
    return censored_words.join(" ")
end

def censoring(star)
    vowels = "aeiou"
    censored = ""
    star.each_char do |char|
        if vowels.include?(char.downcase)
            censored +="*"
        else
            censored +=char
        end
    end
    return censored
end

def power_of_two?(num)
    product = 1
    while product < num
        product *=2
    end
    if product == num
        true
    else
        false
    end
end