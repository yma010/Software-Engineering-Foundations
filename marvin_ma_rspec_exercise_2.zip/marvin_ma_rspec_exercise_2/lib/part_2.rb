def palindrome?(str)
    str.each_char.with_index do |char, i|
        if str[i] != str[ -i -1 ]
            return false
        end
    end
    true
end

def substrings(string)
    new_arr = []
    (0...string.length).each do |start_idx|
        (start_idx...string.length).each do |end_idx|
            new_arr << string[start_idx..end_idx]
        end
    end        
    return new_arr
end

def palindrome_substrings(string)
    substrings_arr = substrings(string)
    subPali = []

    substrings_arr.each do |check|
        if check.length >= 2
            if palindrome?(check) == true
                subPali << check
            end
        end
    end
    return subPali
end