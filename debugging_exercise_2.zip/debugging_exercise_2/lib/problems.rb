# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.
def largest_prime_factor(num)
    num.downto(2) do |factor|
        return factor if num % factor == 0 && is_prime(factor)
    end
end

def is_prime(num)
    return false if num < 2
    (2...num).none? { |i| num % i == 0 }
end

def unique_chars?(string)
    arr = []
    string.each_char do |char|
        return false if arr.include?(char)
        arr << char
    end
    true
end

def dupe_indices(arr)
    dupe = Hash.new { |h, k| h[k] = [] }
    arr.each_with_index do |ele, i|
        dupe[ele] << i
    end
    dupe.select { |k, v| v.length > 1}
end

def ana_array(arr_1, arr_2)
    hash_count(arr_1) == hash_count(arr_2)

end

def hash_count(arr)
    count = Hash.new(0)
    arr.each {|ele| count[ele] += 1}
    count
end