def my_map(arr, &prc)
    pseudo_map = []
    arr.each {|ele| pseudo_map << prc.call(ele)}
    pseudo_map
end

def my_select(arr, &prc)
    pseudo_select = []
    arr.each  {|ele| pseudo_select << ele if prc.call(ele) == true }
    pseudo_select
end

def my_count(arr, &prc)
    counter = 0
    arr.each {|ele| counter +=1 if prc.call(ele) == true }
    counter
end

def my_any?(arr, &prc)
    arr.each {|ele| return true if prc.call(ele) == true}
    false
end

def my_all?(arr, &prc)
    arr.each { |ele| return false if prc.call(ele) == false}
    true
end

def my_none?(arr, &prc)
    arr.each { |ele| return false if prc.call(ele) == true} 
    true
end