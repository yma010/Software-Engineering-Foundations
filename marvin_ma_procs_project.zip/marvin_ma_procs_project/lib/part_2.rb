def reverser(str, &proc)
    new_str = ""
    new_str = proc.call(str.reverse)
end

def word_changer (str, &proc)
    str.split(" ").map { |word| proc.call(word)}.join(" ")
end

def greater_proc_value (num, procA , procB)
    return procA.call(num) if procA.call(num) > procB.call(num)
    procB.call(num)
end

def and_selector(arr, prcA, prcB)
    arr.select  {|ele| prcA.call(ele) && prcB.call(ele)}
end

def alternating_mapper(arr, prcA, prcB)
    alternating = []

    arr.each_with_index do |ele, i|
        if i.even? == true
            alternating << prcA.call(ele)
        else
            alternating << prcB.call(ele)
        end
    end
    alternating
end