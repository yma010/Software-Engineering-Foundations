class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  attr_reader :pegs

  def self.valid_pegs?(arr)
    arr.all? { |char| POSSIBLE_PEGS.has_key?(char.upcase) }
  end

  def initialize(pegs)
    if Code.valid_pegs?(pegs)
      @pegs = pegs.map {|peg| peg.upcase}
    else
      raise "Not given valid pegs."
    end
  end

  def self.random(length)
    random_pegs = []

    length.times { random_pegs << POSSIBLE_PEGS.keys.sample}

    Code.new(random_pegs)
  end

  def self.from_string(pegs)
    Code.new(pegs.capitalize.split(""))
  end

  def [](idx)
    @pegs[idx]
  end

  def length
    @pegs.length
  end

  def num_exact_matches(guess)
    (0...guess.length).count { |i| guess[i] == @pegs[i] }
  end

  def num_near_matches(guess)
    (0...guess.length).count { |i| guess[i] != @pegs[i] && self.pegs.include?(guess[i]) }
  end

  def ==(code)
    self.pegs == code.pegs
  end
end
