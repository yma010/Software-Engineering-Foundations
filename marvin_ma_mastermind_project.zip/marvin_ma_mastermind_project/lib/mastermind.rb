require_relative "code"

class Mastermind


    def initialize(length)
        @secret_code = Code.random(length)
    end

    def print_matches(code)
        puts "#{@secret_code.num_exact_matches(code)} Exact Matches."
        puts "#{@secret_code.num_near_matches(code)} Near Matches."
    end

    def ask_user_for_guess
        p "Enter a code"
        guess = []
        while guess.length != @secret_code.length #Prevents players from cheating the game by submitting one char each time.          
            guess = Code.from_string(gets.chomp) #Checks for the length of the guess vs secret code
            if guess.length != @secret_code.length
                p "Enter a #{@secret_code.length} character long code"
            end
        end
        self.print_matches(guess)
        guess == @secret_code
    end
end
