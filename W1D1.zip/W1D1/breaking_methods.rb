def money_at_retirement(age)
    half_age = age / 2
    est_childs_bank_account = half_age ** 2
    years_until_retirement = 65 - half_age
    money = 0
    money = est_childs_bank_account * years_until_retirement
end



p money_at_retirement(30) #11250
p money_at_retirement(50) #25000