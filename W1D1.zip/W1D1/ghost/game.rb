require_relative "dictionary"

class Game
    attr_reader :dictionary
    def initialize(player1, player2)
        @player1, @player2 = player1, player2
        @current_player = @player1
        @previous_player = @player2
        @fragment = ""
        @player1_score = 0
        @player2_score = 0
        @dictionary = {}
    end

    def load_dictionary
        file = File.open("dictionary.txt")
        file_data = file.readlines.map(&:chomp)
        file_data.each {|word| @dictionary[word] = true}
    end

    def next_player!
        @current_player, @previous_player = @previous_player, @current_player
    end

    def take_turn(player)
        puts "Enter a character: "
        input = gets.chomp
    end

    def valid_play?(input)
        @dictionary.each do |k, v|
            if input == k
                return false
            end
        end
        true
    end

end

game = Game.new
p game.dictionary.length

