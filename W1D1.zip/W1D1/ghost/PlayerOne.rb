class PlayerOne
    def initialize
        @score = 0
        @name = ""
    end

     def take_turn(player)
        puts "Enter a character: "
        input = gets.chomp
    end
end