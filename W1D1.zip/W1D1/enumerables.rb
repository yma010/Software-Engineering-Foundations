require "byebug"
class Array
    def my_each(&prc)   
        j = 0
        while j < self.length
            prc.call(self[j])
            j += 1
        end
        self
    end

    def my_select(&prc)
        select_arr = []
        self.my_each do |num|
            select_arr << num if prc.call(num)
        end
        select_arr
    end

    def my_reject(&prc)
        reject_arr = []
        self.my_each do |num|
            reject_arr << num if !prc.call(num)
        end
        reject_arr
    end
    
    def my_any?(&prc)
        self.my_each { |num| return true if prc.call(num)}
        false
    end

    def my_all?(&prc)
        self.my_each { |num| return false if !prc.call(num) }
        true
    end

    def my_flatten
        return [self] if !self.is_a? Array
        new_arr = []
        self.my_each do |ele|
            if ele.is_a? Array
                new_arr += ele.my_flatten
            else
                new_arr << ele
            end
        end
        new_arr
    end

    def my_zip(*n)
        new_arr = Array.new(self.length) {[]}
        self.each_with_index do |ele1, i|
            new_arr[i] << self[i]
            n.each_with_index do |ele2, j|
                new_arr[i] << ele2[i]
            end
        end
        new_arr
    end

    def my_rotate(n = 1)
        n > 0 ? n.times {self.rotate_left} : (-1 * n).times {self.rotate_right}
        self
    end 

    def rotate_left
        beginning = self.shift
        self.push(beginning)
    end

    def rotate_right
        ending = self.pop
        self.unshift(ending)
    end

    def my_join(separator = "")
        new_str = ""
        
        self.each_with_index do |ele, i|
            if i < self.length - 1
                new_str += self[i] + separator
            else
                new_str += self[i]
            end
        end
        new_str
    end

    def my_reverse
        reversed = []
        self.my_each do |ele|
            reversed.unshift(ele)
        end
        reversed
    end
end

a = [ "a", "b", "c", "d" ]
p a.my_join         # => "abcd"
p a.my_join("$")    # => "a$b$c$d"

# p [ "a", "b", "c" ].my_reverse   #=> ["c", "b", "a"]
# p [ 1 ].my_reverse               #=> [1]
