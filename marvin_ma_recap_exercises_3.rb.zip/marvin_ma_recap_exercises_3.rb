require "Prime"
require "byebug"
#PART A

def no_dupes?(array)
    counts = Hash.new(0)
    array.each {|ele| counts[ele] +=1}
    counts.select {|ele, count| count == 1}.keys
end

# Examples
# no_dupes?([1, 1, 2, 1, 3, 2, 4])         # => [3, 4]
# no_dupes?(['x', 'x', 'y', 'z', 'z'])     # => ['y']
# no_dupes?([true, true, true])            # => []

def no_consecutive_repeats?(array)
    return true if array.length <= 1
    (0...array.length-1).each_with_index { |ele_1, i|return false if array[i] == array[i+1]}
    true
end

# # Examples
# no_consecutive_repeats?(['cat', 'dog', 'mouse', 'dog'])     # => true
# no_consecutive_repeats?(['cat', 'dog', 'dog', 'mouse'])     # => false
# no_consecutive_repeats?([10, 42, 3, 7, 10, 3])              # => true
# no_consecutive_repeats?([10, 42, 3, 3, 10, 3])              # => false
# no_consecutive_repeats?(['x'])                              # => true
# no_consecutive_repeats?([]) 

def char_indices(str)
    indices = Hash.new{|char, indices| char[indices] = []}
    str.each_char.with_index {|char, i| indices[char].push(i)}
    return indices
end

# Examples
# char_indices('mississippi')   # => {"m"=>[0], "i"=>[1, 4, 7, 10], "s"=>[2, 3, 5, 6], "p"=>[8, 9]}
# char_indices('classroom')     # => {"c"=>[0], "l"=>[1], "a"=>[2], "s"=>[3, 4], "r"=>[5], "o"=>[6, 7], "m"=>[8]}


def longest_streak(str)
    arr = []
    counts = Hash.new{|char, val| char[val] = 0}

    str.split("").each {|n| counts[n] += 1 }
    counts.each { |k, v| arr <<  k * v}
    
    return arr.last if all_equal?(arr)
    arr.max_by(&:length)
end

def all_equal?(arr)
  for i in 0..(arr.size-2)
    if arr[i].length != arr[i+1].length
      return false
    end
  end
  true
end

# # Examples
# p longest_streak('a')           # => 'a'
# p longest_streak('accccbbb')    # => 'cccc'
# p longest_streak('aaaxyyyyyzz') # => 'yyyyy
# p longest_streak('aaabbb')      # => 'bbb'
# p longest_streak('abc')         # => 'c'

def bi_prime?(num)
    (1..num).each do |x|
        (x..num).each do |y|
            if y.prime? && x.prime?
                return true if num == x * y
            end
        end
    end
    false
end

# Examples
# p bi_prime?(14)   # => true
# p bi_prime?(22)   # => true
# p bi_prime?(25)   # => true
# p bi_prime?(94)   # => true
# p bi_prime?(24)   # => false
# p bi_prime?(64)   # => false

def vigenere_cipher(message, keys)
    new_message = ""
    alpha = ('a'..'z').to_a

    message.each_char.with_index do |char, i|
        old_pos = alpha.index(char)
        new_pos = old_pos + keys[i % keys.length]
        new_message += alpha[new_pos % 26]
    end

    new_message
end

# Examples
# p vigenere_cipher("toerrishuman", [1])        # => "upfssjtivnbo"
# p vigenere_cipher("toerrishuman", [1, 2])     # => "uqftsktjvobp"
# p vigenere_cipher("toerrishuman", [1, 2, 3])  # => "uqhstltjxncq"
# p vigenere_cipher("zebra", [3, 0])            # => "ceerd"
# p vigenere_cipher("yawn", [5, 1])             # => "dbbo"

def vowel_rotate(str)
    new_str = str[0..-1]
    vowels = "aeiou"
    vowelsIdx = (0...str.length).select {|i| vowels.include?(str[i])}
    newVowelsIdx = vowelsIdx.rotate(-1)

    vowelsIdx.each_with_index do |vowel, i| 
        new_vowel = str[newVowelsIdx[i]]
        new_str[vowel] = new_vowel
    end
    new_str
end

# Examples
# p vowel_rotate('computer')      # => "cempotur"
# p vowel_rotate('oranges')       # => "erongas"
# p vowel_rotate('headphones')    # => "heedphanos"
# p vowel_rotate('bootcamp')      # => "baotcomp"
# p vowel_rotate('awesome')       # => "ewasemo"

#PART B

class String
    def select(&proc)
        empty_str = ""
        return empty_str if proc.nil?
        self.each_char {|char| empty_str += char if proc.call(char)}
        empty_str
    end

# Examples
# p "app academy".select { |ch| !"aeiou".include?(ch) }   # => "pp cdmy"
# p "HELLOworld".select { |ch| ch == ch.upcase }          # => "HELLO"
# p "HELLOworld".select          # => ""

    def map!(&proc)
        self.each_char.with_index {|char, i| self[i] = proc.call(char, i)}
    end
# Examples
# word_1 = "Lovelace"
# word_1.map! do |ch| 
#     if ch == 'e'
#         '3'
#     elsif ch == 'a'
#         '4'
#     else
#         ch
#     end
# end
# p word_1      # => "Lov3l4c3"

# word_2 = "Dijkstra"
# word_2.map! do |ch, i|
#     if i.even?
#         ch.upcase
#     else
#         ch.downcase
#     end
# end
# p word_2        # => "DiJkStRa"
end

#Part C

def multiply(a, b)
    return 0 if a == 0
    if a > 0 && b > 0
        b = b + multiply(a - 1, b)
    elsif a < 0 && b > 0
        -b = b - multiply(a + 1, b)
    elsif a > 0 && b < 0
        b = b + multiply(a - 1, b)
    else
         b = b.abs + multiply(a + 1, b)
    end
end

# p multiply(3, 5)        # => 15
# p multiply(5, 3)        # => 15
# p multiply(2, 4)        # => 8
# p multiply(0, 10)       # => 0
# p multiply(-3, -6)      # => 18
# p multiply(3, -6)       # => -18
# p multiply(-3, 6)       # => -18

def lucas_sequence(n)
    return [] if n == 0
    return [2,1] if n == 1
    return [2, 1] if n == 2
    sequence = lucas_sequence(n - 1)
    next_sequence = sequence[-1] + sequence[-2]
    sequence << next_sequence
end
# Examples
# p lucas_sequence(0)   # => []
# p lucas_sequence(1)   # => [2]    
# p lucas_sequence(2)   # => [2, 1]
# p lucas_sequence(3)   # => [2, 1, 3]
# p lucas_sequence(6)   # => [2, 1, 3, 4, 7, 11]
# p lucas_sequence(8)   # => [2, 1, 3, 4, 7, 11, 18, 29]

def prime_factorization(n)
    (2...n).each do |x|
        if n % x == 0
            y = n / x
            return [*prime_factorization(x), *prime_factorization(y)]
        end
    end
    [ n ]
end

# Examples
# p prime_factorization(12)     # => [2, 2, 3]
# p prime_factorization(24)     # => [2, 2, 2, 3]
# p prime_factorization(25)     # => [5, 5]
# p prime_factorization(60)     # => [2, 2, 3, 5]
# p prime_factorization(7)      # => [7]
# p prime_factorization(11)     # => [11]
# p prime_factorization(2017)   # => [2017]
