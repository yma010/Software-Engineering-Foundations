def average(num1, num2)
    sum = 0
    avg = 0

    sum = num1 + num2
    avg = sum/2.0
    return avg
end

def average_array(arr)
   return arr.sum / arr.length.to_f
end

def repeat(str, num)
    new_str = ""
    num.times { new_str += str}
    new_str
end

def yell(old_str)
    return old_str.upcase! + "!"
end

def alternating_case(sentence)
    words = sentence.split(" ")

    words.map.with_index do |word, i|
        if i % 2 == 0
            word.upcase!
        else
            word.downcase!
        end
    end
    return words.join(" ")
end

