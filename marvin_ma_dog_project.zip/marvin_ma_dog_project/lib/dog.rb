require "byebug"
class Dog
    attr_reader :name, :breed, :age, :favorite_foods
    def initialize(name, breed, age, bark, favorite_foods)
        @name = name
        @breed = breed
        @age = age
        @bark = bark
        @favorite_foods = favorite_foods
    end

    def age= n
        @age = n
    end

    def bark
        return @bark.upcase! if @age > 3
        @bark.downcase
    end

    def favorite_food? food
        @favorite_foods.each {|fave| return true if fave.downcase == food.downcase}
        false
    end
end
