require_relative "room"

class Hotel
    def initialize(name, cap)
        @name = name
        @rooms = {}
        cap.each do |room_name, cap|
            @rooms[room_name] = Room.new(cap)
        end
    end

    def name
        @name.split(" ").map {|word| word.capitalize!}.join(" ")
    end

    def rooms
        return @rooms
    end

    def room_exists?(room_name)
        @rooms.each_key {|rooms| return true if rooms == room_name }
        false
    end

    def check_in(person , room_name)
        if self.room_exists?(room_name)
          if @rooms[room_name].add_occupant(person)
              p 'check in successful'
          else
              p 'sorry, room is full'
          end
        else
            p 'sorry, room does not exist'
        end
    end

    def has_vacancy?
        @rooms.values.any? { |room| room.available_space > 0}
    end

    def list_rooms
        @rooms.each do |room_name, room|
            puts "#{room_name}: #{room.available_space}"
        end
    end
end
