class Board
    attr_reader :size
    def initialize( n )
        @grid = Array.new(n) {Array.new( n , :N )}
        @size = n * n
    end

    def [] position
        @grid[position[0]][position[1]]
    end

    def []= position, value
        @grid[position[0]][position[1]] = value
    end

    def num_ships
        @grid.flatten.count(:S)
    end

    def attack position
        if self[position] == :S
            self[position] = :H
            puts "you sunk my battleship!"
            return true
        else
            self[position] = :X
            return false
        end
    end

    def place_random_ships
        ships = @size * 0.25
        while self.num_ships < ships
            random_row = rand(0...@grid.length)
            random_column = rand(0...@grid.length)
            position = [random_row, random_column]
            self[position] = :S
        end
    end

    def hidden_ships_grid
        @grid.map do |row|
            row.map do |pos|
                if pos == :S
                    :N
                else
                    pos
                end
            end
        end
    end

    def self.print_grid arr
        arr.each { |grid| puts grid.join(" ") }
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(hidden_ships_grid)
    end
end
