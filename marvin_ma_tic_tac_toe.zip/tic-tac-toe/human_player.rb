require_relative "./board.rb"
class Human
    attr_reader :mark, :name
    def initialize(mark)
        @mark = mark
        @name = "Human"
    end

    def display(board)
        board.grid.each do |row|
            puts row.join(" | ")
        end
    end

    def get_move
        puts "Enter a position with coordinates separated with a space like `0 0`"
        input = gets.chomp.split(" ").map(&:to_i) 
    end

end