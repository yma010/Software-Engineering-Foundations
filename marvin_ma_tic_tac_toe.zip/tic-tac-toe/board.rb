require_relative "human_player"
require_relative "computer_player"
require "byebug"

class Board
    attr_reader :grid

    def initialize
        @grid = Array.new(3) { Array.new(3, :_) }
        @size = 3 * 3
    end
    
    def [](position) 
        @grid[position[0]][position[1]]
    end

    def []=(position, mark) # take in mark should set position equal to mark
        @grid[position[0]][position[1]] = mark
    end

    def place_mark(position, mark)
        if empty?(position)
          self[position] = mark
        else
            raise
        end
    end

    def empty?(position)
        if self[position] == :_
          return true
        end
        false
    end

    def winner
        @grid.each_with_index do |row, j|
            row.each_with_index do |spc, i|
                position = [j, i]
                if !self.empty?(position)
                    if spc == :X || spc == :O
                        #return spc if spc == row[i-2] && row[i-2] == row[i-1] #Horizontal
                        if spc == row[i-2] && spc == row[i-1] 
                            return spc
                        #return spc if spc == @grid[i-2][i] && spc == @grid[i-1][i] #Vertical
                        elsif spc == @grid[j-2][i] && spc == @grid[j-1][i] 
                            return spc
                        #return spc if spc == @grid[i-2][i-2] && spc == @grid[i-1][i-1] #Diagnoal
                        elsif spc == @grid[j-2][i-2] && spc == @grid[j-1][i-1]
                            return spc
                        end
                    end
                end
            end
        end
        nil
    end

    def winning_move?(mark)
        @grid.each_with_index do |row, j|
            row.each_with_index do |spc, i|
                position = [j, i]
                if !self.empty?(position)
                    if spc == mark
                        return row[i] if spc == row[i-1] && spc == row[i-2] #Horizotal Win Cond.
                        return @grid[j][i] if spc == @grid[j-2][i] && spc == @grid[j-1][i] #Vertical Win Cond.
                        return @grid[j][i] if spc == @grid[j-2][i-2] && spc == @grid[j-1][i-1] #Diagnoal Win Cond.
                    end
                end
            end
        end
        false
    end

    def over?
        if self.winner == :X || self.winner == :O
            puts "Game Over!"
            puts "Win for #{self.winner.to_s}"
            return true
        elsif @grid.none? {|row| row.include?(:_) }
            puts 'Tie.'
            return true
        end
        false
    end
end