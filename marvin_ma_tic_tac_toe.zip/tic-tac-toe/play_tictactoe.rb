require_relative "game"
require_relative "board"
require "byebug"

puts "Please select a mark 'X' or 'O'"
mark = gets.chomp.upcase

while !(mark == "X" || mark == "O")
    puts "Please select a mark 'X' or 'O'"
    mark = gets.chomp.upcase
end

coin_flip = rand(2)

if coin_flip == 1
    if mark == 'X'
        game = Game.new(:X, :O)
    else
        game = Game.new(:O, :X)
    end
    game.current_player = game.human_player
    puts 'Human player goes first.'
else
    if mark == 'X'
        game = Game.new(:X, :O)
    else
        game = Game.new(:O, :X)
    end
    game.current_player = game.computer_player
    puts 'Computer player goes first.'
end

game.play