require_relative "./board.rb"
require "byebug"
class Computer
    attr_reader :mark, :name
    def initialize(mark)
        @mark = mark
        @name = "Computer"
    end

    def display(board)
        @board = board
    end

    def get_move
        #puts "Enter a position with coordinates separated with a space like `0 0`"
        cheater = @board.winning_move?(mark)
        return cheater if cheater

        valid = false
        until valid == true
            x = rand(3)
            y = rand(3)
            position = [x , y]
            if @board.empty?(position)
                valid = true
            end
        end
        position
    end

end