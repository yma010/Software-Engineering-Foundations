require_relative "board"
require_relative "human_player"
require_relative "computer_player"
require "byebug"
class Game
    attr_reader :human_player, :computer_player
    attr_accessor :current_player ,:board

    def initialize(markH, markC)
        @board = Board.new
        @current_player = nil
        @human_player = Human.new(markH) ## markH = Human Mark
        @computer_player = Computer.new(markC) ## markC = CPU Mark
    end

    def switch_players!
        if @current_player == @human_player
            @current_player = @computer_player
        else
            @current_player = @human_player
        end
    end

    def play_turn  #which handles the logic for a single turn
        current_player.display(board)
        input1_flag = false
        # byebug

        while input1_flag == false
            input1 = @current_player.get_move
            begin
                @board.place_mark(input1, @current_player.mark)
                input1_flag = true
            rescue
                puts "This is an invalid position, pick again!"
            end
        end
        puts `clear`
        current_player.display(board)
        switch_players!
        puts "#{current_player.name}'s turn"
    end


    def play #which calls #play_turn each time through a loop until Game#over?
        #debugger
        until @board.over?
            self.play_turn
        end
        current_player.display(board)
        switch_players!
        current_player.display(board)
    end
end
